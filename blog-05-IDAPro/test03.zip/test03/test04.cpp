#include<stdio.h>
#include<string.h>

int main()
{
	int i;
	int len;
	char res[9];
	char *num = "eastmount";     //��Կ 
	char *right = "123456789";   //��ȷֵ 
	
	
	//�ж� TS@@XYBVM
	len = strlen(num);
	for(i=0; i<len; i++) {
		res[i] = (right[i]^num[i]); //������
	}
	res[i] = 0;
	printf("The right key is: %s\n", res);
	return 0;
}
